<!DOCTYPE html>
<html lang="en">

  <head>

    <?php include('./partials/header.php')?>

  </head>

  <body>

    <!-- ***** Preloader Start ***** -->
    <div id="preloader">
        <div class="jumper">
            <div></div>
            <div></div>
            <div></div>
        </div>
    </div>  
    <!-- ***** Preloader End ***** -->

    <!-- Header -->
    <?php include('./partials/navbar.php')?>

    <!-- Page Content -->
    <!-- Banner Starts Here -->
    <div class="banner header-text">
      <div class="owl-banner owl-carousel">
        <div class="banner-item-01">
          <div class="text-content">
            <h4>One Place Solution For Students!</h4>
            <h2>HBTU Library</h2>
          </div>
        </div>
        <div class="banner-item-02">
          <div class="text-content">
            <h2>Start Learning with us</h2>
            <h4>Let's help students by sharing this resource and become the part of this initiative</h4>
          </div>
        </div>
        <div class="banner-item-03">
          <div class="text-content">
            <h2>Work with us</h2>
            <h4>Let's help HBTU students by providing important resources</h4>
          </div>
        </div>
      </div>
    </div>
    <!-- Banner Ends Here -->

    <div class="best-features">
      <div class="container">
        <div class="row">
          <div class="col-md-12">
            <div class="section-heading">
              <h2>About Us</h2>
            </div>
          </div>
          <div class="col-md-6">
            <div class="left-content">
              <p>It is a digital library for <a href="#">HBTU university</a> students. Our aim is to create HBTU digital library, a single one place soluton for every student problem related to notes and resource. We are here to provide you all the needed resources that can help you to achieve high percentage in your examination. It is a place which help you to </p>
              <ul class="featured-list">
                <li><a href="#">Access to all the last 5 Years PYQs</a></li>
                <li><a href="#">Access to important chapterwise questions and assignments</a></li>
                <li><a href="#">Unlimited access to all resources withiout thinking about fine( i.e. in physical institute ) because it is free.</a></li>
              </ul>
              <a href="about-us.php" class="filled-button">Read More</a>
            </div>
          </div>
          <div class="col-md-6">
            <div class="right-image">
              <img src="assets/images/about-1-570x350.jpg" alt="">
            </div>
          </div>
        </div>
      </div>
    </div>

    <div class="services" style="background-image: url(assets/images/other-image-fullscren-1-1920x900.jpg);" >
      <div class="container">
        <div class="row">
          <div class="col-md-12">
            <div class="section-heading">
              <h2>Latest blog posts</h2>

              <a href="blog.php">read more <i class="fa fa-angle-right"></i></a>
            </div>
          </div>

          <div class="col-lg-4 col-md-6">
            <div class="service-item">
              <a href="blog-details.php" class="services-item-image"><img src="assets/images/blog-1-370x270.jpg" class="img-fluid" alt=""></a>

              <div class="down-content">
                <h4><a href="blog-details.php">Healthy Mind Leads to Healthy Body</a></h4>

                <p style="margin: 0;"> Aman Kumar Singh &nbsp;&nbsp;|&nbsp;&nbsp; 11/04/23 &nbsp;&nbsp;|&nbsp;&nbsp; 114</p>
              </div>
            </div>
          </div>
          <div class="col-lg-4 col-md-6">
            <div class="service-item">
              <a href="#" class="services-item-image"><img src="assets/images/blog-2-370x270.jpg" class="img-fluid" alt=""></a>

              <div class="down-content">
                <h4><a href="#">The Time Management Skill for Beginners</a></h4>

                <p style="margin: 0;"> Shubham Vaishnav &nbsp;&nbsp;|&nbsp;&nbsp; 11/04/23 &nbsp;&nbsp;|&nbsp;&nbsp; 0</p>
              </div>
            </div>
          </div>
          <div class="col-lg-4 col-md-6">
            <div class="service-item">
              <a href="#" class="services-item-image"><img src="assets/images/blog-3-370x270.jpg" class="img-fluid" alt=""></a>

              <div class="down-content">
                <h4><a href="#">How to Study More Effectively for Beginners</a></h4>

                <p style="margin: 0;"> Devansh Gupta &nbsp;&nbsp;|&nbsp;&nbsp; 11/04/23 &nbsp;&nbsp;|&nbsp;&nbsp; 0</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

    <div class="call-to-action">
      <div class="container">
        <div class="row">
          <div class="col-md-12">
            <div class="inner-content">
              <div class="row">
                <div class="col-md-8">
                  <h4>Let's work with us</h4>
                  <p>Let's us connect with me and my team, so that we can work with each other and build a better society by creating content on the web. Connect with me on <b>linkedin</b> or via <b>email</b>. </p><br>
                </div>
                <div class="col-lg-4 col-md-6 text-right">
                  <a href="contact.php" class="filled-button">Contact Us</a>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

    
    <?php include('./partials/footer.php')?>
  </body>
</html>