<!DOCTYPE html>
<html lang="en">

  <head>

    <?php include('./partials/header.php')?>

  </head>

  <body>

    <!-- ***** Preloader Start ***** -->
    <div id="preloader">
        <div class="jumper">
            <div></div>
            <div></div>
            <div></div>
        </div>
    </div>  
    <!-- ***** Preloader End ***** -->

    <!-- Header -->
    <?php include('./partials/navbar.php')?>

    <!-- Page Content -->
    
<div class="page-heading about-heading header-text" style="background-image: url(assets/images/heading-2-1920x500.jpg);">
      <div class="container">
        <div class="row">
          <div class="col-md-12">
            <div class="text-content">
              <h4>Lorem ipsum dolor</h4>
              <h2>Temperature Convertor</h2>
            </div>
          </div>
        </div>
      </div>
    </div>
 

    <div class="container my-3">
    <p>
      <label>Fahrenheit</label>
      <input id="inputFahrenheit" type="number" placeholder="Fahrenheit" oninput="temperatureConverter(this.value)" onchange="temperatureConverter(this.value)">
    </p>
    <p>Celcius: <span id="outputCelcius"></span></p>
    </div>
     
    

    <!-- Convertor -->
    <div class="container">

    <main>
        <!-- <header>
            <h1>Converter</h1>
        </header> -->
        <div class="inputs">
            <input type="number" name="celcius" id="celcius" class="input" placeholder="Celcius">
            <input type="number" name="fahrenheit" id="fahrenheit" class="input" placeholder="Fahrenheit">
            <input type="number" name="kelvin" id="kelvin" class="input" placeholder="Kelvin">
        </div>
    </main>
    </div>
    
    

  <?php include('./partials/footer.php') ?>


  </body>
  <!-- For code 1  -->
  <script> 
    function temperatureConverter(valNum) {
      valNum = parseFloat(valNum);
      document.getElementById("outputCelcius").innerHTML=(valNum-32)/1.8;
    }
  </script>
  

  <!--For code 2-->
  <script>
  const celciusInput = document.getElementById("celcius");
  const fahrenheitInput = document.getElementById("fahrenheit");
  const kelvinInput = document.getElementById("kelvin");

  // <!-- console.log(celciusInput)
  // console.log(fahrenheitInput)
  // console.log(kelvinInput) -->

  const inputs = document.getElementsByClassName("input");
  // <!-- console.log(inputs) -->

  for(let i=0; i<inputs.length; i++) {
      let input = inputs[i];

      input.addEventListener("input", function(e) {
          let value = parseFloat(e.target.value);

          switch(e.target.name) {
              case "celcius":
                  fahrenheitInput.value = (value * 1.8) + 32;
                  kelvinInput.value = value + 273.15;
                  break;
              case "fahrenheit":
                  celciusInput.value = (value - 32) / 1.8;
                  kelvinInput.value = ((value - 32) / 1.8) + 273.15;
                  break;
              case "kelvin":
                  celciusInput.value = value - 273.15;
                  fahrenheitInput.value = ((value - 273.15) * 1.8) + 32;
                  break;
          }
      });
  }
  </script>

</html>
