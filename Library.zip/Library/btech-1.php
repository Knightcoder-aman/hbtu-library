<!DOCTYPE html>
<html lang="en">

  <head>

    <?php include('./partials/header.php')?>

  </head>
  <link rel="stylesheet" href="assets/css/table.css">
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Playfair+Display:400,400i,700,700i|Raleway:300,300i,400,400i,500,500i,600,600i,700,700i">
  <style>
    @media screen and (max-width: 701px) {
      #main-h {
        font-size: 23px;
        margin-left: -85px;
      }
      .main-h3{
        font-size: 21px;
      }
    }

    @media screen and (max-width: 600px) {
      #main-h {
        font-size: 21px;
        margin-left: -155px;
      }
      .main-h3{
        font-size: 19px;
      }
    }
    
    @media screen and (max-width: 550px) {
      #main-h {
        font-size: 19px;
        margin-left: -175px;
      }
      .main-h3{
        font-size: 18px;
      }
    }

    @media screen and (max-width: 483px) {
      #main-h {
        font-size: 19px;
        margin-left: -148px;
      }
      .main-h3{
        font-size: 18px;
      }
    }

    @media screen and (max-width: 377px) {
      #main-h {
        font-size: 17px;
        margin-left: -148px;
      }
      .main-h3{
        font-size: 16px;
      }
    }

    @media screen and (max-width: 300px) {
      #main-h {
        font-size: 15px;
        margin-left: -148px;
      }
      .main-h3{
        font-size: 16px;
      }
    }
  </style>
  <body>

    <!-- ***** Preloader Start ***** -->
    <div id="preloader">
        <div class="jumper">
            <div></div>
            <div></div>
            <div></div>
        </div>
    </div>  
    <!-- ***** Preloader End ***** -->

    <!-- Header -->
    <?php include('./partials/navbar.php')?>

    <!-- Page Content -->
    
<div class="page-heading about-heading header-text" style="background-image: url(assets/images/heading-2-1920x500.jpg);">
      <div class="container">
        <div class="row">
          <div class="col-md-12">
            <div class="text-content">
              <h4>BTECH - 1st Year</h4>
              <h2>PYQs and Assignments</h2>
            </div>
          </div>
        </div>
      </div>
    </div>
    
    <!-- <div class="container d-flex justify-content-center my-5"> -->
    <div class="container d-flex justify-content-center my-5 position-absolute top-150 start-0 translate-middle-y">
    <div id="heading" class="twelve text-center">
      <h1 id="main-h">B.Tech(Common) 1st Year PYQs</h1>
    </div>
    </div>
    <div class="container">
    <div class="page-content page-container" id="page-content">
    <div class="padding">
        <div class="row container d-flex justify-content-center">
    
        <h3 class="main-h3 d-block p-2">Chemistry PYQs -</h3>
    <div class="col-lg-8 grid-margin stretch-card my-3">
              <div class="card" id="card">
                <div class="card-body">
                  <h4 class="card-title">Chemistry</h4>
                  <p class="card-description">
                   Download the past 5 year preavious question paper of chemistry from here.
                  </p>
                  <div class="table-responsive">
                    <table class="table">
                      <thead>
                        <tr>
                          <th>PYQs</th>
                          <th>Link to the PDF</th>
                        </tr>
                      </thead>
                      <tbody>
                        <tr>
                          <td>PYQ 2021</td>
                          <td><a>click here</a></td>
                        </tr>
                        <tr>
                          <td>PYQ 2020</td>
                          <td><a>click here</a></td> 
                        </tr>
                        <tr>
                          <td>PYQ 2019</td>
                          <td><a>click here</a></td>
                        </tr>
                        <tr>
                          <td>PYQ 2018</td>
                          <td><a>click here</a></td>  
                        </tr>
                        <tr>
                          <td>PYQ 2017</td>
                          <td><a>click here</a></td>
                        </tr>
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>

            <!-- FMEM PDFs -->
            <h3 class="main-h3 d-block p-2">ICE PYQs -</h3>
            <div class="col-lg-8 grid-margin stretch-card my-3">
              <div class="card" id="card">
                <div class="card-body">
                  <h4 class="card-title">ICE</h4>
                  <p class="card-description">
                   Download the past 5 year preavious question paper of ICE from here.
                  </p>
                  <div class="table-responsive">
                    <table class="table">
                      <thead>
                        <tr>
                          <th>PYQs</th>
                          <th>Link to the PDF</th>
                        </tr>
                      </thead>
                      <tbody>
                        <tr>
                          <td>PYQ 2021</td>
                          <td><a>Click here</a></td>
                        </tr>
                        <tr>
                          <td>PYQ 2020</td>
                          <td><a>Click here</a></td> 
                        </tr>
                        <tr>
                          <td>PYQ 2019</td>
                          <td><a>Click here</a></td>
                        </tr>
                        <tr>
                          <td>PYQ 2018</td>
                          <td><a>Click here</a></td>  
                        </tr>
                        <tr>
                          <td>PYQ 2017</td>
                          <td><a>Click here</a></td>
                        </tr>
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>



            <!-- IETE PDFs -->
            <h3 class="main-h3 d-block p-2">IETE PYQs -</h3>
            <div class="col-lg-8 grid-margin stretch-card my-3">
              <div class="card" id="card">
                <div class="card-body">
                  <h4 class="card-title">IETE</h4>
                  <p class="card-description">
                   Download the past 5 year preavious question paper of IETE from here.
                  </p>
                  <div class="table-responsive">
                    <table class="table">
                      <thead>
                        <tr>
                          <th>PYQs</th>
                          <th>Link to the PDF</th>
                        </tr>
                      </thead>
                      <tbody>
                        <tr>
                          <td>PYQ 2021</td>
                          <td><a>click here</a></td>
                        </tr>
                        <tr>
                          <td>PYQ 2020</td>
                          <td><a>click her</a></td> 
                        </tr>
                        <tr>
                          <td>PYQ 2019</td>
                          <td><a>click here</a></td>
                        </tr>
                        <tr>
                          <td>PYQ 2018</td>
                          <td><a>click here</a></td>  
                        </tr>
                        <tr>
                          <td>PYQ 2017</td>
                          <td><a>click here</a></td>
                        </tr>
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>


            <!-- ICT -->
            <h3 class="main-h3 d-block p-2">ICT PYQs -</h3>
            <div class="col-lg-8 grid-margin stretch-card my-3">
              <div class="card" id="card">
                <div class="card-body">
                  <h4 class="card-title">ICT</h4>
                  <p class="card-description">
                   Download the past 5 year preavious question paper of ICT from here.
                  </p>
                  <div class="table-responsive">
                    <table class="table">
                      <thead>
                        <tr>
                          <th>PYQs</th>
                          <th>Link to the PDF</th>
                        </tr>
                      </thead>
                      <tbody>
                        <tr>
                          <td>PYQ 2021</td>
                          <td><a>click here</a></td>
                        </tr>
                        <tr>
                          <td>PYQ 2020</td>
                          <td><a>click here</a></td> 
                        </tr>
                        <tr>
                          <td>PYQ 2019</td>
                          <td><a>click here</a></td>
                        </tr>
                        <tr>
                          <td>PYQ 2018</td>
                          <td><a>click here</a></td>  
                        </tr>
                        <tr>
                          <td>PYQ 2017</td>
                          <td><a>click here</a></td>
                        </tr>
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>


            <!-- Physics -->
            <h3 class="main-h3 d-block p-2">Physics PYQs -</h3>
            <div class="col-lg-8 grid-margin stretch-card my-3">
              <div class="card" id="card">
                <div class="card-body">
                  <h4 class="card-title">Engg. Physics</h4>
                  <p class="card-description">
                   Download the past 5 year preavious question paper of Physics from here.
                  </p>
                  <div class="table-responsive">
                    <table class="table">
                      <thead>
                        <tr>
                          <th>PYQs</th>
                          <th>Link to the PDF</th>
                        </tr>
                      </thead>
                      <tbody>
                        <tr>
                          <td>PYQ 2021</td>
                          <td><a>click here</a></td>
                        </tr>
                        <tr>
                          <td>PYQ 2020</td>
                          <td><a>click here</a></td> 
                        </tr>
                        <tr>
                          <td>PYQ 2019</td>
                          <td><a>click here</a></td>
                        </tr>
                        <tr>
                          <td>PYQ 2018</td>
                          <td><a>click here</a></td>  
                        </tr>
                        <tr>
                          <td>PYQ 2017</td>
                          <td><a>click here</a></td>
                        </tr>
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>

            <!-- Maths 1 -->
            <h3 class="main-h3 d-block p-2">Engg. Maths-I PYQs -</h3>
            <div class="col-lg-8 grid-margin stretch-card my-3">
              <div class="card" id="card">
                <div class="card-body">
                  <h4 class="card-title">Engg. Maths I</h4>
                  <p class="card-description">
                   Download the past 5 year preavious question paper of Engg. Maths I from here.
                  </p>
                  <div class="table-responsive">
                    <table class="table">
                      <thead>
                        <tr>
                          <th>PYQs</th>
                          <th>Link to the PDF</th>
                        </tr>
                      </thead>
                      <tbody>
                        <tr>
                          <td>PYQ 2021</td>
                          <td><a>click here</a></td>
                        </tr>
                        <tr>
                          <td>PYQ 2020</td>
                          <td><a>click here</a></td> 
                        </tr>
                        <tr>
                          <td>PYQ 2019</td>
                          <td><a>click here</a></td>
                        </tr>
                        <tr>
                          <td>PYQ 2018</td>
                          <td><a>click here</a></td>  
                        </tr>
                        <tr>
                          <td>PYQ 2017</td>
                          <td><a>click here</a></td>
                        </tr>
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>

            <!-- Math 2 -->
            <h3 class="main-h3 d-block p-2">Engg. Maths-II PYQs -</h3>
            <div class="col-lg-8 grid-margin stretch-card my-3">
              <div class="card" id="card">
                <div class="card-body">
                  <h4 class="card-title">Engg. Maths II</h4>
                  <p class="card-description">
                   Download the past 5 year preavious question paper of Engg. Maths II from here.
                  </p>
                  <div class="table-responsive">
                    <table class="table">
                      <thead>
                        <tr>
                          <th>PYQs</th>
                          <th>Link to the PDF</th>
                        </tr>
                      </thead>
                      <tbody>
                        <tr>
                          <td>PYQ 2021</td>
                          <td><a>click here</a></td>
                        </tr>
                        <tr>
                          <td>PYQ 2020</td>
                          <td><a>click here</a></td> 
                        </tr>
                        <tr>
                          <td>PYQ 2019</td>
                          <td><a>click here</a></td>
                        </tr>
                        <tr>
                          <td>PYQ 2018</td>
                          <td><a>Click here</a></td>  
                        </tr>
                        <tr>
                          <td>PYQ 2017</td>
                          <td><a>Click here</a></td>
                        </tr>
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>


            <!-- END -->
            
            </>
              </div>
              </div>
            </div>

  <?php include('./partials/footer.php') ?>


  </body>
</html>
