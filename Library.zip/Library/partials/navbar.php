<header class="">
      <nav class="navbar navbar-expand-lg">
        <div class="container">
          <a class="navbar-brand" href="index.php"><h2>HBTU <em>Library</em></h2></a>
          <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
          </button>
          <div class="collapse navbar-collapse" id="navbarResponsive">
            <ul class="navbar-nav ml-auto">
                <li class="nav-item active">
                    <a class="nav-link" href="index.php">Home
                      <span class="sr-only">(current)</span>
                    </a>
                </li> 

                <li class="nav-item"><a class="nav-link" href="about-us.php">About Us</a></li>

                <!-- <li class="nav-item"><a class="nav-link" href="blog.php">Blog</a></li> -->
                <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                  BTECH
                </a>
                <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                  <li><a class="dropdown-item" href="btech-1.php">1st Year</a></li>
                  <li><a class="dropdown-item" href="btech-2.php">2nd Year</a></li>
                  <li><a class="dropdown-item" href="btech-3.php">3rd Year</a></li>
                  <li><a class="dropdown-item" href="btech-4.php">4th Year</a></li>
                  
                </ul>
                </li>

                <li class="nav-item"><a class="nav-link" href="blog.php">Blogs</a></li>

                <li class="nav-item"><a class="nav-link" href="contact.php">Contact Us</a></li>
                
            </ul>
          </div>
        </div>
      </nav>
    </header>


    