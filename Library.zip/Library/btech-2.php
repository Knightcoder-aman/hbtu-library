<!DOCTYPE html>
<html lang="en">

  <head>

    <?php include('./partials/header.php')?>

  </head>

  <body>

    <!-- ***** Preloader Start ***** -->
    <div id="preloader">
        <div class="jumper">
            <div></div>
            <div></div>
            <div></div>
        </div>
    </div>  
    <!-- ***** Preloader End ***** -->

    <!-- Header -->
    <?php include('./partials/navbar.php')?>

    <!-- Page Content -->
    
<div class="page-heading about-heading header-text  my-4" style="background-image: url(assets/images/heading-2-1920x500.jpg);">
      <div class="container">
        <div class="row">
          <div class="col-md-12">
            <div class="text-content">
              <h4>B.Tech. - 2nd Year</h4>
              <h2>PYQs and Assignments</h2>
            </div>
          </div>
        </div>
      </div>
    </div>
    
    <!-- Convertor -->
    <div class="container">
    <h1>B.Tech 2nd Year Notes</h1>
       Here, You will get all the desired notes and assignments for BTECH 2nd year(All branches). But due to some issues we
       are unable to provide you notes and assignments for BTECH 2nd year.
       We will solve this issue very soon. Thank You
    </div>

  <?php include('./partials/footer.php') ?>


  </body>
</html>
